import style from '../../pages/Main/Main.module.css';

interface MainInterface {
    name: string
    price: string
    MainImg:string
    img1: string
    img2: string
    img3: string
    img4: string
}

export function bigTablo(a:any)
    //@ts-ignore
     { a.map((item: MainInterface, index: number) => (
            <li  className={style.item}>
                <h2>{item.name}</h2>
                <h3>{item.price}</h3>
                <img src={item.MainImg} alt="" />
                <img src={item.img1} alt="" />
                <img src={item.img2} alt="" />
                <img src={item.img3} alt="" />
                <img src={item.img4} alt="" />
                <img src={item.img1} alt="" />
            </li>
    ))}