import { Route, Routes } from 'react-router-dom'

const Home = () => (
    <>
        Home
    </>
)
export default Home